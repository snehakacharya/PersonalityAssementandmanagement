<html> 
<head> 
<title> Rate us </title> 
</head> 
<body> 
<p style="text-align:center;font-size:400%"> 
Enter your rating </p> 
<p style="text-align:left;font-size:150%">
Enter your rating here</p>
        <form action="logout.php" method="post">
		<p style="text-align:right">
		<input type="submit" value="Log out">
		</p>
		</form>
		<form action="addrating.php" method="post">
		<p style="text-align:center;font-size:120%;">
			<label for="rate">Rating:</label>
			<input type="text" name="rate" required>
		</P>
<p style="text-align:center;font-size:22px;">
			<input type="submit" value="Login" /></p>
		</form>
		</body>
</html>