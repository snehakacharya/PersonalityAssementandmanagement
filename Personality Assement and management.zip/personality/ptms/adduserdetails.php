<?php
$username = $_POST['username'];
$name = $_POST['name'];
$email= $_POST['email'];
$age= $_POST['age'];
$phonenumber= $_POST['phonenumber'];


    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "personality";
	
	
	
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) 
	{
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } 
	else 
	{
     $SELECT = "SELECT username From userdetails Where username= ? Limit 1";
	 $CHECK= "select username from register where username=? Limit 1";
     $INSERT = "INSERT Into userdetails (username,name,email,age,phonenumber) values(?,?,?,?,?)";
	 if($phonenumber>1000000000 && $phonenumber<10000000000)
	 {
          $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $username);
     $stmt->execute();
     $stmt->bind_result($username);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
	  
     if ($rnum==0)
	 {
      $stmt->close();
	  $stmt = $conn->prepare($CHECK);
     $stmt->bind_param("s", $username);
     $stmt->execute();
     $stmt->bind_result($username);
     $stmt->store_result();
     $rnum1 = $stmt->num_rows;
	 if($rnum1==1)
	 {
		 $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param('sssii',$username,$name,$email,$age,$phonenumber);
      $stmt->execute();
      echo "<br><p align='center'> <font color=blue  size='50pt'>You have successfully been registered</font> </p>";
	echo '<a href="mainpage.php"><p align=center><font size=5 >Click here to go back to the mainpage</a></font> </p>';

	  $stmt->close();
     $conn->close();
    }
	else {
		echo "User not registered";
	}
	 }
	else 
	 {
      echo"<br><p align='center'> <font color=blue  size='50pt'>User already registered</font> </p>"; 
	}
	 
	}
	else{
	echo "Invalid Phone number";
	}
	}
	?>