-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2019 at 05:43 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `personality`
--

-- --------------------------------------------------------

--
-- Table structure for table `mbti`
--

CREATE TABLE `mbti` (
  `username` varchar(20) NOT NULL,
  `extro` int(3) NOT NULL,
  `intu` int(3) NOT NULL,
  `feel` int(3) NOT NULL,
  `pros` int(3) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mbti`
--

INSERT INTO `mbti` (`username`, `extro`, `intu`, `feel`, `pros`, `date`) VALUES
('akshay30', 80, 45, 65, 45, '2018-12-26'),
('akshay30', 40, 55, 65, 25, '2018-12-28'),
('akshay30', 25, 25, 25, 25, '2018-12-29'),
('akshay30', 25, 40, 65, 40, '2018-12-30'),
('akshay30', 25, 25, 25, 25, '2019-01-18'),
('shilpa', 75, 75, 80, 65, '2018-11-30');

-- --------------------------------------------------------

--
-- Table structure for table `psycho`
--

CREATE TABLE `psycho` (
  `username` varchar(20) NOT NULL,
  `apathy` int(3) NOT NULL,
  `neuro` int(3) NOT NULL,
  `narc` int(3) NOT NULL,
  `lie` int(3) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `psycho`
--

INSERT INTO `psycho` (`username`, `apathy`, `neuro`, `narc`, `lie`, `date`) VALUES
('akshay', 65, 65, 65, 65, '2018-11-16'),
('akshay30', 25, 25, 25, 25, '2018-11-16'),
('akshay30', 20, 20, 20, 20, '2018-12-12'),
('akshay30', 20, 20, 20, 20, '2018-12-14'),
('akshay30', 68, 68, 68, 68, '2018-12-20'),
('akshay30', 100, 84, 84, 100, '2018-12-22'),
('akshay30', 20, 20, 20, 20, '2018-12-30');

-- --------------------------------------------------------

--
-- Table structure for table `psyresult`
--

CREATE TABLE `psyresult` (
  `username` varchar(20) NOT NULL,
  `result` varchar(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `psyresult`
--

INSERT INTO `psyresult` (`username`, `result`, `date`) VALUES
('akshay', 'Probably a psychopath', '2018-11-16'),
('akshay30', 'Probably not a psychopath', '2018-11-16'),
('akshay30', 'Probably not a psychopath', '2018-12-12'),
('akshay30', 'Probably not a psychopath', '2018-12-14'),
('akshay30', 'Probably a psychopath', '2018-12-20'),
('akshay30', 'Probably a psychopath', '2018-12-22'),
('akshay30', 'Probably not a psychopath', '2018-12-30');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`username`, `password`) VALUES
('akshay', 'akshay'),
('akshay30', 'akshay'),
('joshua', 'joshua'),
('libin', '123456li'),
('shilpa', 'shilpa');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `username` varchar(20) NOT NULL,
  `extro` varchar(1) NOT NULL,
  `intu` varchar(1) NOT NULL,
  `feel` varchar(1) NOT NULL,
  `pros` varchar(1) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`username`, `extro`, `intu`, `feel`, `pros`, `date`) VALUES
('akshay30', 'E', 'S', 'F', 'J', '2018-12-26'),
('akshay30', 'I', 'N', 'F', 'J', '2018-12-28'),
('akshay30', 'I', 'S', 'T', 'J', '2018-12-29'),
('akshay30', 'I', 'S', 'F', 'J', '2018-12-30'),
('akshay30', 'I', 'S', 'T', 'J', '2019-01-18'),
('shilpa', 'E', 'N', 'F', 'P', '2018-11-30');

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE `userdetails` (
  `username` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `age` int(11) NOT NULL,
  `phonenumber` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetails`
--

INSERT INTO `userdetails` (`username`, `name`, `email`, `age`, `phonenumber`) VALUES
('akshay', 'Akshay Hrithik', 'kings.p.theawesome@gmail.com', 19, 1234567890),
('akshay30', 'Akshay Hrithik', 'kings.p.theawesome@gmail.com', 19, 8892893572),
('joshua', 'Joshua', 'kings.p.theawesome@gmail.com', 20, 1234567890),
('libin', 'libinlouis', 'libin.gmail.com', 19, 9999999999),
('shilpa', 'shilpa', 'sh@gmail.com', 21, 1234567890);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mbti`
--
ALTER TABLE `mbti`
  ADD PRIMARY KEY (`username`,`date`);

--
-- Indexes for table `psycho`
--
ALTER TABLE `psycho`
  ADD PRIMARY KEY (`username`,`date`);

--
-- Indexes for table `psyresult`
--
ALTER TABLE `psyresult`
  ADD PRIMARY KEY (`username`,`date`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`username`,`date`);

--
-- Indexes for table `userdetails`
--
ALTER TABLE `userdetails`
  ADD PRIMARY KEY (`username`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mbti`
--
ALTER TABLE `mbti`
  ADD CONSTRAINT `mbti_ibfk_1` FOREIGN KEY (`username`) REFERENCES `register` (`username`);

--
-- Constraints for table `psyresult`
--
ALTER TABLE `psyresult`
  ADD CONSTRAINT `psyresult_ibfk_1` FOREIGN KEY (`username`) REFERENCES `psycho` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `type`
--
ALTER TABLE `type`
  ADD CONSTRAINT `type_ibfk_1` FOREIGN KEY (`username`) REFERENCES `mbti` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `userdetails`
--
ALTER TABLE `userdetails`
  ADD CONSTRAINT `userdetails_ibfk_1` FOREIGN KEY (`username`) REFERENCES `register` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
