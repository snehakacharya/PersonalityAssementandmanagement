<?php
	session_start();
   include('session.php');
   
	 	     $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "personality";
	
	
	
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) 
	{
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } 
		$username = $_SESSION['username'];
		$extro =($_POST['e1']+$_POST['e2']+$_POST['e3']+$_POST['e4']+$_POST['e5'])*5;
		$intu = ($_POST['i1']+$_POST['i2']+$_POST['i3']+$_POST['i4']+$_POST['i5'])*5;
		$feel = ($_POST['f1']+$_POST['f2']+$_POST['f3']+$_POST['f4']+$_POST['f5'])*5;
		$pros = ($_POST['p1']+$_POST['p2']+$_POST['p3']+$_POST['p4']+$_POST['p5'])*5;
		$date=$_POST['date'];
		$INSERT = "INSERT Into mbti (username,extro,intu,feel,pros,date) values(?,?,?,?,?,?)";
		$CHECK="SELECT username from mbti where username =? and date =? Limit 2";
		if($extro>=0 && $extro<=100 && $intu>=0 && $intu<=100 && $feel>=0 && $feel<=100 && $pros>=0 && $pros<=100)
		{
		$stmt=$conn->prepare($CHECK);
		$stmt->bind_param('ss',$username,$date);
		$stmt->execute();
		$stmt->bind_result($username);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
	 if($rnum==0)
	 {
		  $stmt->close();
          $stmt = $conn->prepare($INSERT);
     $stmt->bind_param("siiiis", $username,$extro,$intu,$feel,$pros,$date);
     $stmt->execute(); 
	 $stmt->close();
	 echo"Inserted and";
	 if($extro<50 && $intu>=50 && $feel<50 && $pros<50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'I', 'N', 'T', 'J', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro<50 && $intu>=50 && $feel<50 && $pros>=50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'I', 'N', 'T', 'P', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"Type Determined";
	 }
	 }
	 if($extro<50 && $intu>=50 && $feel>=50 && $pros<50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'I', 'N', 'F', 'J', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"T\nype Determined";
	 }
	 }
	 if($extro<50 && $intu>=50 && $feel>=50 && $pros>=50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'I', 'N', 'F', 'P', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro<50 && $intu<50 && $feel<50 && $pros<50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'I', 'S', 'T', 'J', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro<50 && $intu<50 && $feel<50 && $pros>=50)
	 {
		$sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'I', 'S', 'T', 'P', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro<50 && $intu<50 && $feel>=50 && $pros<50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'I', 'S', 'F', 'J', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro<50 && $intu<50 && $feel>=50 && $pros>=50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'I', 'S', 'F', 'P', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 
	 
	 if($extro>=50 && $intu>=50 && $feel<50 && $pros<50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'E', 'N', 'T', 'J', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro>=50 && $intu>=50 && $feel<50 && $pros>=50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'E', 'N', 'T', 'P', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro>=50 && $intu>=50 && $feel>=50 && $pros<50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'E', 'N', 'F', 'J', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro>=50 && $intu>=50 && $feel>=50 && $pros>=50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'E', 'N', 'F', 'P', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro>=50 && $intu<50 && $feel<50 && $pros<50)
	 {
		 $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'E', 'S', 'T', 'J', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro>=50 && $intu<50 && $feel<50 && $pros>=50)
	 {
		  $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'E', 'S', 'T', 'P', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro>=50 && $intu<50 && $feel>=50 && $pros<50)
	 {
		  $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'E', 'S', 'F', 'J', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 if($extro>=50 && $intu<50 && $feel>=50 && $pros>=50)
	 {
		  $sql = "INSERT INTO type (username, extro, intu, feel, pros, date)
VALUES ('$username', 'E', 'S', 'F', 'P', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"\nType Determined";
	 }
	 }
	 	 echo "\n";
	 echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
	 }
	 else {
		 echo "Reached maximum Limit for today";
		 echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
	 }
		}
		else {
			echo "Please enter values between 0 to 100";
			echo '<a href="mbti.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
		}
	?>
