<html> 
<head> 
<title> MBTI Test Results </title> 
<link rel="stylesheet" type="text/css" href="choice.css"> 
</head> 
<body> 

<h1> Welcome </h1> 
<p>
You can store and keep track of your MBTI and Psychopath test tesults
</p>  
<br> </br> <br> </br>
<form action="logout.php" method="post">
		<p style="text-align:right">
		<input type="submit" value="Log out">
		</p>
		</form>
		
		<form action="updateuser.php" method="post">
		<p style="text-align:right">Click here to update user information
		<input type="submit" value="Update">
		</p>
		</form>
		<p>
		<div class="mbti">
		<h2> MBTI Result Management</h2>
<br> </br>
<div id="i">
You can store and analyse your results here
</div>
<form action="mbtitest.php" method="POST">
<p style="text-align:left;font-size:22px;">Click here to take the MBTI test. 
			<input type="submit" value="Take Test" /></p>
		</form>
		<form action="displaymbti.php" method="POST">
<p style="text-align:left;font-size:22px;">Click here to view test scores
			<input type="submit" value="View Scores" /></p>
		</form>
		<form action="displaytype.php" method="POST">
<p style="text-align:left;font-size:22px;">Click here to view personality type
			<input type="submit" value="View Type" /></p>
		</form>
		<form action="delmbti.php" method="POST">
<p style="text-align:left;font-size:22px;">Delete result by date
			<input type="submit" value="Delete" /></p>
		</form>
		
		</div>
		</p>
		<br> </br> <br> </br>
		<div class="psy">
<h2> Psychopath Result Management </h2> 
<p>
You can store and analyse your results here
</p> 
<form action="psytest.php" method="POST">
<p style="text-align:left;font-size:22px;">Click here to take the Psychopath test
			<input type="submit" value="Take Test" /></p>
		</form>
		<form action="displaypsycho.php" method="POST">
<p style="text-align:left;font-size:22px;">Click here to view test scores
			<input type="submit" value="view scores" /></p>
		</form>
		<form action="displaypsyresult.php" method="POST">
<p style="text-align:left;font-size:22px;">Click here to view test results
			<input type="submit" value="view results" /></p>
		</form>
		<form action="delpsycho.php" method="POST">
<p style="text-align:left;font-size:22px;">Click here to delete result by date
			<input type="submit" value="Delete" /></p>
		</form>
		
		<br> </br> <br> </br>
</div>		
	</body> 
</html> 	

