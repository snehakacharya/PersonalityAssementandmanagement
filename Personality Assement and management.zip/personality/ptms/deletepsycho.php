<?php
session_start();
   include('session.php');
$username = $_SESSION['username'];
$date= $_POST['date'];

    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "personality";
	
	
	
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) 
	{
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } 
	else {
		$SELECT="SELECT username FROM psycho where username=? and date=?";
		$stmt = $conn->prepare($SELECT);
     $stmt->bind_param("ss", $username,$date);
     $stmt->execute();
     $stmt->bind_result($username);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==1)
	 {
		$sql = "DELETE FROM psycho WHERE username='$username' and date='$date'"; 
if($conn->query($sql) == true){ 
    echo "Record was deleted successfully."; 
	echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>'; 
	}
	 }
	else {
		echo "Record doesn't exist";
		echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
	}
	}
	?>