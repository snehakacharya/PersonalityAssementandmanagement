<!doctype html>
<html> 
<head> 
<title> Register Form </title>
<link rel="stylesheet" type="text/css" href="reg.css"> 
</head> 
<body>
<div id="head">
<p>
Regester your information here  </p>
</div>		
<div id="body">
		<p> 
Enter your details below, all fields are mandatory. 
</p> 
		
		<form action="addreg.php" method="post">


		<p>
			<label for="username"> New UserName :</label>
			<input type="text" name="username" required>
		</P>
		
		<p>
			<label for="password">New Password :</label>
			<input type="password" name="password" required>
		</P>

		<p>
		<input type="submit" name= "Register" value="Register" /> 
		</P>
		</form>
		</div>
	
		
</body>
</html>
		
