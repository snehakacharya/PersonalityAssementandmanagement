<?php
session_start();
   include('session.php');
$username = $_SESSION['username'];

    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "personality";
	
	
	
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) 
	{
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } 
	else {
		$query = "SELECT * FROM mbti where username='$username'";
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($conn,$query);
 
// If the query executed properly proceed
if($response){
	echo '<table align="left" border="2"
cellspacing="5" cellpadding="8">
 
<tr><td align="left"><b>Extrovertism %</b></td>
<td align="left"><b>Intuition %</b></td>
<td align="left"><b>Feeling %</b></td>
<td align="left"><b>Prospecting %</b></td>
<td align="left"><b>Date</b></td></tr>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left">' . 
$row['extro'] . '</td><td align="left">' .
$row['intu'] . '</td><td align="left">' .
$row['feel'] . '</td><td align="left">' .
$row['pros'] . '</td><td align="left">' .
$row['date'] . '</td>';
 
echo '</tr>';
}
 
echo '</table>';
 
} else {
	echo 'No data found';
	echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
}
	}
?> 