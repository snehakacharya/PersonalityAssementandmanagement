<html> 
<head> 
<title> Psychopath Test </title> 
</head> 
<body> 
<div>
<h1> Welcome </h1> 
<p>
You can get a pretty good estimate of your psychopathic tendencies here
</div> 
<br> </br> <br> </br>
<form action="addpsy.php" method="post">
<p> 
<p> DATE: 
<input type="date" name="date"  required />
</p>
<br></br>
<p> Answer the following on a scale of 1 to 5. </p> 
Do you feel indifferent towards people?
<select name="a1">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br> 
Do you feel unaffected by any and all social occurences that happen around you? 
<select name="a2" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you feel like you can't connect with people on an emotional basis?
<select name="a3" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
You don't pay attention to conversations do you?
<select name="a4" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Have you felt like someone's death would benefit you better than their life?
<select name="a5" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you consider yourself to be emotionally instable? 
<select name="ne1" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you have see people as a means to obtain your objective?  
<select name="ne2" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you always feel empty, like everything around you is not as it should be? 
<select name="ne3" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you feel like anxiety and depression surging from within?
<select name="ne4" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you lose control of yourself when things don't go the way you like them to? 
<select name="ne5" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you have a grandiose perception of self?
<select name="n1" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you exploit others with no guilt or shame?
<select name="n2" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you often intimidate or belittle others?
<select name="n3" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you feel like the world recognizes your grandeur?
<select name="n4" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you feel like people can't understand how unique and special you are?
<select name="n5" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you like to lie and manipulate people? 
<select name="l1" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you spin a web of lies to cover one and never give in to the truth?
<select name="l2" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you study people to exploit them later?   
<select name="l3" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Would you count your behaviours as "strange"?
<select name="l4" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
You aren't a psychopath, are you?
<select name="l5" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
<input type="submit" value="submit"/>
</p> 
</form>
</body> 
</html> 