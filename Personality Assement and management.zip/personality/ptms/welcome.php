<?php
   include('session.php');
   header("location: choice.php");
?>
