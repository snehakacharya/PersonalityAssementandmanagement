<html> 
<head> 
<title> Psychopath Test Results </title> 
</head> 
<body> 
<p style="text-align:center;font-size:400%"> 
Psychopath Test Result Management </p> 
<p style="text-align:left;font-size:150%">
You can keep track of your most recent records and alter them or compar your test results with other user's recent results</p>
        <form action="logout.php" method="post">
		<p style="text-align:right">
		<input type="submit" value="Log out">
		</p>
		</form>
		<form action="addpsy.php" method="post">
		<p style="text-align:center;font-size:120%;">
			<label for="apathy">Apathy %:</label>
			<input type="text" name="apathy" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="neuro">Neuroticism % :</label>
			<input type="text" name="neuro" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="narc"> Narcissism % :</label>
			<input type="text" name="narc" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="lie">Compulsive Lying % :</label>
			<input type="text" name="lie" required>
		</P>
		<p style="text-align:center;font-size:120%;">
		Date:
			<input type="date" name="date" required>
		</P> 
		</P>
				<p style="text-align:center;">
		<input type="submit" name= "Submit" value="Submit" /> 
		</P>
		</form>
		<p style="text-align:left;font-size:150%"> 
		dasfegrwwvrdcw
		</p> 
</body> 
</html>