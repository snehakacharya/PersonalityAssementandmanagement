<?php
session_start();
   include('session.php');
$username = $_SESSION['username'];

    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "personality";
	
	
	
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) 
	{
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } 
	else {
		$query = "SELECT * FROM psycho where username='$username'";
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($conn,$query);
 
// If the query executed properly proceed
if($response){
	echo '<table align="left" border="2"
cellspacing="5" cellpadding="8">
 
<tr><td align="left"><b>Apathy %</b></td>
<td align="left"><b>Neuroticism %</b></td>
<td align="left"><b>Narcissim %</b></td>
<td align="left"><b>Compulsive Lying%</b></td>
<td align="left"><b>Date</b></td></tr>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left">' . 
$row['apathy'] . '</td><td align="left">' .
$row['neuro'] . '</td><td align="left">' .
$row['narc'] . '</td><td align="left">' .
$row['lie'] . '</td><td align="left">' .
$row['date'] . '</td>';
 
echo '</tr>';
}
 
echo '</table>';
 
} else {
	echo 'No data found';
	echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
}
	}
?> 