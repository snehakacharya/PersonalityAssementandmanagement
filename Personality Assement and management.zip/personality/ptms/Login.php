<!doctype html>
<html>
<head>
<title> Login form </title>
<style> 
body {
    background-image: url("pexels-photo-988872.jpeg");
}
div {
	border: solid #1a1a1a;
}
</style>
	</head>	
	
	
	
	<body>
	<div>
	<p style="text-align:center;padding:50px;font-size:250%;"><b> Enter your Login details </b></p>
	
	
		<form action="checklogin.php" method="POST">


		<p style="text-align:center;font-size:120%;">
			<label for="username">Enter Username:</label>
			<input type="text" name="username" required /></p>
			
			
			<p style="text-align:center;font-size:120%;">
			<label for="password">Enter Password:</label>
			<input type="password" name="password" required /></p>
			<br />
			
			<p style="text-align:center;font-size:22px;">
			<input type="submit" value="Login" /></p>
		</form>
		
		</div>
	</body>
</html>
