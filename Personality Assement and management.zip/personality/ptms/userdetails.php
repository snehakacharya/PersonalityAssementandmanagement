<!doctype html>
<html> 
<head> 
<title> User Details </title> 
<style> 
body {
    background-image: url("pexels-photo-988872.jpeg");
}
</style>
</head> 
<body>
<p style="text-align:center; font-size:30px">
Regester your information here  
</p>
		<hr color="black"></hr>
		

		<p style="text-align:center;font-size:300%"> 
Enter your drtails below, all fields are mandatory. 
</p> 
		
		<form action="adduserdetails.php" method="post">


		<p style="text-align:center;font-size:120%;">
			<label for="username"> UserName :</label>
			<input type="text" name="username" required>
		</P>
		
		<p style="text-align:center;font-size:120%;">
			<label for="name">Name :</label>
			<input type="text" name="name" required>
		</P>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="email"> Email ID:</label>
			<input type="text" name="email" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="age"> Age:</label>
			<input type="text" name="age" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="phonenumber"> Phone Number:</label>
			<input type="text" name="phonenumber" required>
		</P>
				<p style="text-align:center;">
		<input type="submit" name= "Register" value="Register" /> 
		</P>
		</form>
		</p>
		
</body>
</html>