<!doctype html>
<html> 
<head> 
<title>Update User Details </title> 
</head> 
<body>
<h1> Update your information </h1> 
<br> </br>
<form action="updateuserdetails.php" method="post">
<p style="text-align:center;font-size:120%;">
			<label for="name">Name :</label>
			<input type="text" name="name" required>
		</P>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="email"> Email ID:</label>
			<input type="text" name="email" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="age"> Age:</label>
			<input type="text" name="age" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="phonenumber"> Phone Number:</label>
			<input type="text" name="phonenumber" required>
		</P>
				<p style="text-align:center;">
		<input type="submit" value="Update" /> 
		</P>
		</form> 
		</body> 
		</html> 
