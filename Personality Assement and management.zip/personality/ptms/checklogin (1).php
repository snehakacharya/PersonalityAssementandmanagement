<?php
session_start();


    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "personality";
	
	
	
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) 
	{
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } 
	else 
	{   if ( ! empty( $_POST ) )
		{
    if ( isset( $_POST['username'] ) && isset( $_POST['password'] ) ) {
        // Getting submitted user data from database
        
        $stmt = $conn->prepare("SELECT * FROM register WHERE username = ?");
        $stmt->bind_param('s', $_POST['username']);
        $stmt->execute();
        $result = $stmt->get_result();
    	$user = $result->fetch_object();
    		
    	// Verify user password and set $_SESSION
    	if ( $_POST['password']== $user->password )
			{
			
         $_SESSION['username'] = $user->username;
         
         header("location: welcome.php");
    	}
		else 
		{
			echo"Login failed";
		}
    }
		}
	}

?>