<html> 
<head> 
<title> MBTI Test</title> 
</head> 
<body> 
<div>
<h1> Welcome </h1> 
<p>
Your MBTI personality type and the percentages of the base attributes can be calculated by taking this test.
</div> 
<br> </br> <br> </br>
<form action="addmbti.php" method="post">
<p> 
<p> DATE: 
<input type="date" name="date"  required />
</p>
<br></br>
<p> Answer the following on a scale of 1 to 5. </p> 
Do you find it difficult to introduce yourself to people?
<select name="e1">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br> 
Do you feel energized after spending time with people? 
<select name="e2" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you prefer social gatherings over a quiet time doing stuff you like?
<select name="e3" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
In a room full of people do you prefer to stick closer to the walls? 
<select name="e4" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
How long would it take for you to adjust to your new work environment? 
<select name="e5" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you stand on your opinion even if it isn't supported by facts? 
<select name="i1" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you blindly follow your "gut feeling"? 
<select name="i2" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Are you a visionary? 
<select name="i3" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you tend to read between the lines? 
<select name="i4" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you crave for meaning behind relatively trivial things? 
<select name="i5" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Are your decisions more dependant on your feeling and not thought?
<select name="f1" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Would you find it difficult to find a loyal, but underperforming employee?
<select name="f2" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Logic isn't more important than your prejudice when it comes to making decisions, how true is this?
<select name="f3" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you believe being tactful is more important than telling the "cold" truth?
<select name="f4" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you feel nervous when there is no harmony around you?
<select name="f5" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you make well thought out travel plans? 
<select name="p1" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Can you stick to a timetable? 
<select name="p2" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Is it hard for you to stick to one topic? 
<select name="p3" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Do you encourage autonomy?
<select name="p4" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
Doth thou expend a lot of time for preparation? 
<select name="p5" />
<option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
<br> </br>
<input type="submit" value="submit"/>
</p> 
</form>
</body> 
</html> 