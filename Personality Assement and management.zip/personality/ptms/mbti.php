
<html> 
<head> 
<title> MBTI Test Results </title> 
</head> 
<body> 
<p style="text-align:center;font-size:400%"> 
MBTI Result Management </p> 
<p style="text-align:left;font-size:150%">
You can keep track of your most recent records and alter them or compar your test results with other user's recent results</p>
        <form action="logout.php" method="post">
		<p style="text-align:right">
		<input type="submit" value="Log out">
		</p>
		</form>
		<form action="addmbti.php" method="post">
		<p style="text-align:center;font-size:120%;">
			<label for="extro">Extroverion %:</label>
			<input type="text" name="extro" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="intu">Intuition % :</label>
			<input type="text" name="intu" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="feel">Feeling % :</label>
			<input type="text" name="feel" required>
		</P>
		<p style="text-align:center;font-size:120%;">
			<label for="pros">Prospecting % :</label>
			<input type="text" name="pros" required>
		</P>
		<p style="text-align:center;font-size:120%;">
		Date:
			<input type="date" name="date" required>
		</P> 
		</P>
				<p style="text-align:center;">
		<input type="submit" name= "Submit" value="Submit" /> 
		</P>
		
</body> 
</html>
		