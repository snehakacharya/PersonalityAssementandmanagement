
<!DOCTYPE html> 
<html> 
<head> 
<title> Personality Management system </title>
<link rel="stylesheet" type="text/css" href="main.css">
</head> 
<body> 
<h1>
PERSONALITY TYPE ASSESSMENT AND MANAGEMENT 
</h1>
<div id="log">
<form method="get" action="Register.php" > 
<p style="text-align:right;font-size:22p;"> 
Click here if you are a new user 
<input type="submit" name="Register" value="REGISTER" align="middle"> 
</p> 
</form>
<form method="get" action="Login.php" > 
<p style="text-align:right;font-size:22p;"> 
Click here if you are an existing user 
<input type="submit" name="Log in" value="LOGIN" align="middle"> 
</p> 
</form> 
</div> 
<div id="pic">
<p style="text-align:center;">
<img src="16-personalities-test.png" height="400" width="800"> 
</p> 
</div>
<h2>About MBTI and Psychopathy </h2>
<div id="text">
<p style="text-align:left">
<b>
The purpose of the Myers-Briggs Type Indicator® (MBTI®) personality inventory is to make the theory of psychological types described by C. G. Jung understandable and useful in people's lives. The essence of the theory is that much seemingly random variation in the behavior is actually quite orderly and consistent, being due to basic differences in the ways individuals prefer to use their perception and judgment.
<br></br>
"Perception involves all the ways of becoming aware of things, people, happenings, or ideas. Judgment involves all the ways of coming to conclusions about what has been perceived. If people differ systematically in what they perceive and in how they reach conclusions, then it is only reasonable for them to differ correspondingly in their interests, reactions, values, motivations, and skills."
<br> </br>
Psychopathy is among the most difficult disorders to spot. The psychopath can appear normal, even charming. Underneath, he lacks conscience and empathy, making him manipulative, volatile and often (but by no means always) criminal. They are objects of popular fascination and clinical anguish: adult psychopathy is largely impervious to treatment, though programs are in place to treat callous, unemotional youth in hopes of preventing them from maturing into psychopaths.
<br></br>
The terms “psychopath” and “sociopath” are often used interchangeably, but in correct parlance a “sociopath” refers to a person with antisocial tendencies that are ascribed to social or environmental factors, whereas psychopathic traits are more innate, though a chaotic or violent upbringing may tip the scales for those already predisposed to behave psychopathically. Both constructs are most closely represented in the Diagnostic and Statistical Manual of Mental Disorders (DSM) as Antisocial Personality Disorder. Brain anatomy, genetics, and a person’s environment may all contribute to the development of psychopathic traits.
</b>
</p>
</div>
</body>
</html>

