<?php
session_start();
   include('session.php');
$username = $_SESSION['username'];
$name = $_POST['name'];
$email= $_POST['email'];
$age= $_POST['age'];
$phonenumber= $_POST['phonenumber'];


    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "personality";
	
	
	
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) 
	{
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } 
	else 
	{
		if($phonenumber>=1000000000 && $phonenumber<=9999999999)
		{
		$UPDATE = "UPDATE userdetails set name=?, email=?, age=?, phonenumber=? where username=? Limit 5";
		$stmt=$conn->prepare($UPDATE);
		$stmt->bind_param('ssiis',$name,$email,$age,$phonenumber,$username);
		$stmt->execute();
		echo 'Updated'; 
		echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
		}
		else {
			echo "Invalid phonenumber";
		}
	}
	?>
		