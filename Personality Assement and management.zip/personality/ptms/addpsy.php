<?php
	session_start();
   include('session.php');
   
	 	     $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "personality";
	
	
	
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) 
	{
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } 
		$username = $_SESSION['username'];
		$apathy =($_POST['a1']+$_POST['a2']+$_POST['a3']+$_POST['a4']+$_POST['a5'])*5;
		$neuro = ($_POST['ne1']+$_POST['ne2']+$_POST['ne3']+$_POST['ne4']+$_POST['ne5'])*5;
		$narc = ($_POST['n1']+$_POST['n2']+$_POST['n3']+$_POST['n4']+$_POST['n5'])*5;
		$lie = ($_POST['l1']+$_POST['l2']+$_POST['l3']+$_POST['l4']+$_POST['l5'])*5;
		$date=$_POST['date'];
		if($apathy>=0 && $apathy<=100 && $neuro>=0 && $neuro<=100 && $narc>=0 && $narc<=100 && $lie>=0 && $lie<=100)
		{
		$INSERT = "INSERT Into psycho (username,apathy,neuro,narc,lie,date) values(?,?,?,?,?,?)";
		$CHECK="SELECT username from psycho where username =? and date =? Limit 2";
		$stmt=$conn->prepare($CHECK);
		$stmt->bind_param('ss',$username,$date);
		$stmt->execute();
		$stmt->bind_result($username);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
	 if($rnum==0)
	 {
		  $stmt->close();
          $stmt = $conn->prepare($INSERT);
     $stmt->bind_param("siiiis", $username,$apathy,$neuro,$narc,$lie,$date);
     $stmt->execute(); 
	 echo 'Inserted and'; 
	 echo "\n";
	  echo "\n";
	 if($apathy>50 && $neuro >50 && $narc>50 && $lie>50)
	 {
	 $sql = "INSERT INTO psyresult (username, result, date)
VALUES ('$username', 'Probably a psychopath', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"Result Determined";
	echo "/n";
	 echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
	 }
	 }
	 else {
		 $sql = "INSERT INTO psyresult (username, result, date)
VALUES ('$username', 'Probably not a psychopath', '$date')";

if ($conn->query($sql) === TRUE) {
    echo"Result Determined";
	echo "\n";
	 echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
}
	 }
	 }
	 else {
		 echo "Reached maximum Limit for today";
		 echo '<a href="choice.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
	 }
		}
		else
		{
			echo" Please enter values between 0 to 100.";
			echo '<a href="psy.php"><p align=center><font size=5 >Click here to go back</a></font> </p>';
		}
	?>
